var app=angular.module("myApp",[]);


app.controller("MyController",function($scope){
    $scope.items=["item 1", "item 2" ,"item 3", "item 4", "item 5"];
    $scope.emp=[{name: "xxx", id: "111"},{name: "yyy", id: "100"}];
});
