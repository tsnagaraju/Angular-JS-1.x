var app=angular.module("myApp",[]);

app.factory("mydb",function(){
    var obj=[{name: 'Ram', id:'164'},{name:'Madhu', id:'110'},{name:'Anu', id:'100'}];
    return obj;
});

/*app.factory("mydb",function(){
	var ftry = {};
    ftry.obj=function(){
		var objVal=[{name: 'Ram', id:'164'},{name:'Madhu', id:'110'},{name:'Anu', id:'100'}];
		return objVal;
	}
	return ftry;
});*/