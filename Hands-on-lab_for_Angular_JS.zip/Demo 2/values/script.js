var myModule = angular.module("myModule", []);

myModule.value("numberValue", 999);

myModule.value("stringValue", "abc");

myModule.value("objectValue", { val1 : 123, val2 : "abc"} );


myModule.controller("MyController", function($scope, objectValue) {

    $scope.sval=objectValue;

});

/*myModule.controller("MyController", function($scope, stringValue) {

    $scope.sval=stringValue;

});

myModule.controller("MyController", function($scope, objectValue) {

    $scope.sval=objectValue;

});*/