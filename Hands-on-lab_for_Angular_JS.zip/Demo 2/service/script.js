var app=angular.module("myApp",[]);

app.factory("mydb",function(){
    var obj=[10, 20,30];
    return obj;
});

function calcTotal(mydb){
  this.total = function(){
	  var tot = 0;
	  for(var i=0; i< mydb.length; i++){
		tot= tot+ mydb[i];
	  }
	  return tot;
  }
}

app.service("MyService", calcTotal);

app.controller("MyController",function($scope, mydb, MyService){
    $scope.firstdb=mydb;
	$scope.calTotal = MyService.total();
});
