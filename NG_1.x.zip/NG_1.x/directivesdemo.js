angular.module('myApp', [])
    .controller('MyController', function ($scope) {
        $scope.imageUrl = "D:/Users/nasetti/Pictures/Wishes.png"
    })