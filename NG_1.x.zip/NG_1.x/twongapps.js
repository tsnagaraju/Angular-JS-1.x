angular.module('moduleOne', [])
    .controller('MyControllerOne', function ($scope) {
        $scope.name = "nagaraju setti"
    })

angular.module('moduleTwo', [])
    .controller('MyControllerTwo', function ($scope) {
        $scope.city = "Hyderabad"
    })

angular.element(document).ready(function () {
    let myDiv1 = document.getElementById('div1')
    let myDiv2 = document.getElementById('div2')
    angular.bootstrap(myDiv1, ['moduleOne', 'moduleTwo'])
    angular.bootstrap(myDiv2, ['moduleTwo'])
})    