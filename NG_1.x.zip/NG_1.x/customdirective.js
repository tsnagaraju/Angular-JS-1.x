angular.module('myApp', [])
    .controller('MyController', function ($scope) {
        $scope.dt = new Date()
    })
    .directive('myDate', function () {
        return {
            restrict: 'E',
            template: '<div> {{dt}} {{user}} </div>',
            replace: true,
            scope: {
                user: '@'
            }
        }
    })
