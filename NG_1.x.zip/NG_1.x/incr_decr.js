angular.module('myApp', [])
    .controller('IncrDecrController', function ($scope) {
        $scope.count = 0;
        $scope.increment = () => {
            $scope.count += 1
        }
        $scope.decrement = () => {
            $scope.count -= 1
        }
    })