angular.module('app', [])
    .controller('BindingController', function ($scope) {
        $scope.message = "Good Morning"
        $scope.wish = function () {
            $scope.message = "Good Afternoon"
        }
    })
    .directive('callWish', function () {
        return {
            restrict: 'E',
            scope: {
                callback: '&'
            },
            template: '<button ng-click="callback()">Submit</button>'
        }
    })