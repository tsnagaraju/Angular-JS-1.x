angular.module('app', [])
    .controller('TranscludeController', function ($scope) { })
    .directive('box', function () {
        return {
            template: '<p class="bg-primary text-center" ng-transclude></p>',
            transclude: true
        }
    })