angular.module('myApp', [])
    .controller('MyController', function ($scope) {
        $scope.name = "nagaraju setti"
    })