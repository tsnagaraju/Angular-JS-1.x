angular.module('myApp', [])
    .controller('LanguageController', function ($scope) {
        $scope.languages = ['java', 'pega', 'react', 'angular']
        $scope.selectedLanguage = ''
    })