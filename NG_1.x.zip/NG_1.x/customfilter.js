angular.module('myApp', [])
    .filter('initcaps', function () {
        return function (input) {
            if (input) {
                return input[0].toUpperCase() + input.slice(1)
            }
        }
    })
    .controller('MyController', function ($scope, $filter) {
        $scope.firstname = $filter('uppercase')('nagaraju')
    })