angular.module('app', [])
    .controller('ScopeController', function ($scope) {
        $scope.message = "the scope controller"
        $scope.message1 = "directive 1"
        $scope.message2 = "directive 2"
    })
    .directive("message", function () {
        return {
            template: '<p>Hello from {{message}}</p>',
            scope: {
                message: '='
            }
        }
    })

    // scope.$eval to access a scope property passed as a string argument
    // to direactive