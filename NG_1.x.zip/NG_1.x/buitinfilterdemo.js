angular.module('myApp', [])
    .controller('MyController', function ($scope) {
        $scope.firstname = "nagaraju"
        $scope.lastname = "SETTI"
        $scope.num = 1900.349
        $scope.price = 499
        $scope.skills = ['java', 'pega', 'react', 'angular', 'node', 'vue']
        $scope.products = [
            { id: 1, name: 'apple', price: 29 },
            { id: 2, name: 'mango', price: 12 },
            { id: 3, name: 'orange', price: 44 },
            { id: 4, name: 'banana', price: 9 }
        ]
        $scope.today = new Date()
    })