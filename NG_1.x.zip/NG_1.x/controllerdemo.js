angular.module('myApp', [])
    .controller('ParentController', function ($scope) {
        $scope.person = {
            name: 'Nagaraju',
            city: 'hyd'
        }
    })
    .controller('ChildController', function ($scope) {
        $scope.person.name = "Nagaraju Setti"
        $scope.person.city = "Hyderabad"
    })