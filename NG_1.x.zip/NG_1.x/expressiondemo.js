angular.module('myApp', [])
    .controller('ExpressionController', function ($scope) {
        $scope.name = "nag"
        $scope.$watch('name', function (newVal, oldVal, scope) {
            console.log('New Value: ' + newVal)
            console.log('old Value: ' + oldVal)
        })
    })