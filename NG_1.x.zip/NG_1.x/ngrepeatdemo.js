angular.module('myApp', [])
    .controller('NgrepeatController', function ($scope) {
        $scope.skills = ['java', 'pega', 'react', 'angular']
        $scope.products = [
            { id: 1, name: 'apple', price: 12 },
            { id: 2, name: 'banana', price: 8 },
            { id: 3, name: 'mango', price: 19 }
        ]
    })