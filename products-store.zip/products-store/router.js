angular.module('myApp', ['ngRoute'])
    .config(function ($routeProvider, $locationProvider) {
        $locationProvider.hashPrefix('')
        $routeProvider
            .when('/', {
                template: `
                <div>
                <table class="table">
                <tr><th>ID</th><th>Name</th><th>Price</th></tr>
                <tr ng-repeat="p in products">
                <td>{{p.id}}</td>
                <td>{{p.name}}</td>
                <td>{{p.price}}</td>
                <td><a href="#/update/{{p.id}}" class="btn btn-info">Update</a></td>
                <td><button class="btn btn-danger" ng-click="remove(p.id)">Delete</button></td>
                </tr>
                </table>
                <a href="#/add" class="btn btn-primary">Add</a>
                </div>
                `,
                controller: 'ProductsController'
            })
            .when('/add', {
                template: `
                Name: <input type="text" ng-model="product.name" name="name" class="form-control"/>
                Price: <input type="text" ng-model="product.price" name="price" class="form-control"/>
                <button class="btn btn-success" ng-click="add()">Add</button>
                `,
                controller: 'AddController'
            })
            .when('/update/:id', {
                template: `
                Id: <input type="text" class="form-control" ng-model="product.id" readonly/>
                Name: <input type="text" ng-model="product.name" name="name" class="form-control"/>
                Price: <input type="text" ng-model="product.price" name="price" class="form-control"/>
                <button class="btn btn-success" ng-click="update()">Save</button>
                `,
                controller: 'UpdateController'
            })
    })
    .controller('ProductsController', function ($scope, getall, $http) {
        getall.then((res) => $scope.products = res.data)
        $scope.remove = (pid) => {
            $http.delete('http://localhost:3000/products/' + pid)
                .then(() => {
                    alert('deleted...')
                    history.go()
                })
        }
    })
    .controller('AddController', function ($scope, $http, $location) {
        $scope.product = {
            name: '',
            price: ''
        }
        $scope.add = () => {
            $http.post(' http://localhost:3000/products', $scope.product)
                .then(() => {
                    alert('added...')
                    $location.path('/')
                })
        }
    })
    .controller('UpdateController', function ($scope, $http, $location, $routeParams) {
        $http.get(' http://localhost:3000/products/' + $routeParams.id)
            .then((res) => $scope.product = res.data)
        $scope.update = () => {
            $http.put('http://localhost:3000/products/' + $routeParams.id, $scope.product)
                .then(() => {
                    alert('updated...')
                    $location.path('/')
                })
        }
    })
    .factory('getall', function ($http) {
        return $http.get(' http://localhost:3000/products')
    })