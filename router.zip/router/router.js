angular.module('myApp', ['ngRoute'])
    .config(function ($routeProvider, $locationProvider) {
        $locationProvider.hashPrefix('')
        $routeProvider
            .when('/', {
                template: '<p>{{message}}</p>',
                controller: 'DefaultController'
            })
            .when('/about', {
                template: '<p>this is about page</p>'
            })
            .when('/contact/:name', {
                template: '<p>Please Contact Mr. {{empName}} </p>',
                controller: 'ContactController'
            })
            .otherwise({
                redirectTo: '/'
            })
    })

    .controller('DefaultController', function ($scope) {
        $scope.message = 'This is a default controller for default route'
    })
    .controller('ContactController', function ($scope, $routeParams) {
        $scope.empName = $routeParams.name
    })
