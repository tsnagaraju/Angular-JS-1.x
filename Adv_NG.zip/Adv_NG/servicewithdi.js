angular.module('app', [])
    .config(function ($provide) {
        $provide.decorator('score', function ($delegate) {
            $delegate.points = 100
            return $delegate
        })
    })
    .controller('ScoreController', function ($scope, score, randomScore) {
        $scope.score = score;
        $scope.increment = () => {
            $scope.score.points += randomScore()
        }
    })
    .service('score', Score)
    .value('randomScore', function () {
        return Math.ceil(Math.random() * 10)
    })

function Score(randomScore) {
    this.points = randomScore()
}