angular.module('app', [])
    //.value('score', 0)
    .value('score', { points: 0 })
    .controller('ScoreController', function ($scope, score, randomScore) {
        $scope.score = score;
        $scope.increment = function () {
            $scope.score.points += randomScore()
        }
    })
    .value('randomScore', function () {
        return Math.ceil(Math.random() * 10)
    })