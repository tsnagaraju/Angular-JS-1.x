angular.module('app', [])
    .value('randomScore', function () {
        return Math.ceil(Math.random() * 10)
    })
    .factory('score', function (randomScore) {
        //return { points: randomScore() }
        let points = randomScore();
        return {
            increment: function () {
                return ++points
            },
            getPoints: function () {
                return points;
            }
        }
    })
    .controller('ScoreController', function ($scope, score, randomScore) {
        $scope.score = score;
        $scope.increment = () => {
            $scope.score.increment()
        }
    })