angular.module('app', [])
    .controller('HttpController', function ($scope, $http) {
        $scope.products = []
        $scope.getAll = () => {
            $http.get(' http://localhost:3000/products')
                .then((res) => $scope.products = res.data)
        }
        $scope.add = () => {
            let p = { name: 'banana', price: 8 }
            $http.post(' http://localhost:3000/products', p)
                .then(() => alert('added...'))
        }
        $scope.update = () => {
            let p = { name: 'mango', price: 12 }
            $http.put(' http://localhost:3000/products/3', p)
                .then(() => alert('updated...'))
        }
        $scope.remove = () => {
            $http.delete(' http://localhost:3000/products/4')
                .then(() => alert('deleted...'))
        }
    })